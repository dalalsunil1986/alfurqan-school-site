<!--START LEFT SIDEBAR OPEN-->
<div class="nicdark_left_sidebar nicdark_bg_greydark nicdark_nicescrool nicdark_dark_widgets">

    <a style="z-index:9;" class="nicdark_left_sidebar_btn_close nicdark_btn_icon small nicdark_bg_red nicdark_radius white nicdark_absolute_right10 nicdark_shadow"><i class="icon-power"></i></a>
    
    <!--start widgets-->
    <div class="nicdark_margin020">
        <?php if ( ! dynamic_sidebar( 'sidebar-open-left' ) ) : ?><?php endif ?>
    </div>
    <!--end widgets-->

</div>
<!--END RIGHT SIDEBAR OPEN-->